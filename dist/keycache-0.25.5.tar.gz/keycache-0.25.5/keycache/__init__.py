

# github.com/psytron/keycache
# USAGE :
# keycache.set_system_encrypt_key( sysfinger.generate() )
# keycache.get('healthity' , alias='healthity')
# future usage
# levels.set( 'alias L 0' ,'domain L 1' )
# def set( self , 'level_0' , 'level_1'):
#   print(' next level ')



from .keycache import Keycache